#pragma once

// header added for fb2k mobile compatibility