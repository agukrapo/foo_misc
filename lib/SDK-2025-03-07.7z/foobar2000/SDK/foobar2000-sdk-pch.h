#pragma once
#include "foobar2000-lite.h"
