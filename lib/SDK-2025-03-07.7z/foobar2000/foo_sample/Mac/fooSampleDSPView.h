//
//  fooSampleDSPView.h
//  foo_sample
//
//  Created by P on 01/09/2023.
//

#import <Cocoa/Cocoa.h>


@interface fooSampleDSPView : NSViewController
@end
