#pragma once

void ToggleCapture();
bool IsCaptureRunning();