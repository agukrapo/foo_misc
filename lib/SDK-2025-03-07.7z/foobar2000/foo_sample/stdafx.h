#ifdef __cplusplus
#include <helpers/foobar2000+atl.h>
#endif

#ifdef __OBJC__
#include <Cocoa/Cocoa.h>
#endif
