#pragma once

bool uSetClipboardString(const char * ptr);
bool uGetClipboardString(pfc::string_base & out);
