#pragma once

HWND CListControl_ReplaceListView(HWND);
HWND CListControl_ReplaceListBox(HWND);