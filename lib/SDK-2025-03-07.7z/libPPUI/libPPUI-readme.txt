libPPUI

A library of user interface classes used by foobar2000 codebase; freely available for anyone to use in their programming projects.
